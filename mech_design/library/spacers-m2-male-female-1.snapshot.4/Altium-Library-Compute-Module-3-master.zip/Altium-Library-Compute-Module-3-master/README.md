# Altium Part - Compute Module 3

This repository contains my library containing parts for the Compute Module 3. I have broken up the various pins according to the pin functions in the datasheet and labelled them accordingly.

Do note that this is UNTESTED. Do point out any mistakes that I may have made or any feedback that you may have.

The SODIMM socket is the one used in the official IO board, part number 1473005-4. The footprint for this part is from [RS](http://sg.rs-online.com/web/p/dimm-sockets/5422685).
